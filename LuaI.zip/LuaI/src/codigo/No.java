/*
 * 
 */
package codigo;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Rodrigo
 */
public class No {   //E as arvores somos nozes
    private String conteudo;
    private final No pai;
    private final List<No> filhos = new ArrayList<>();
    
    public No(No pai) {
        this.pai = pai;
    }
    
    public No(No pai, String c){
        this.pai = pai;
        this.conteudo = c;
    }

    public String getConteudo() {
        return conteudo;
    }

    public void setConteudo(String conteudo) {
        this.conteudo = conteudo;
    }

    public No getPai() {
        return pai;
    }

    public List<No> getFilhos() {
        return filhos;
    }
    
    public static No novoFilho(No pai, String conteudo) { 
        No no = new No(pai);
        no.setConteudo(conteudo);
        pai.getFilhos().add(no);
        return no;
    }

    @Override
    public String toString() {
        String resp = this.toString(0);
        return resp;
    }
    public String toString(int profundidade) {
        String resp = "";
        for (int i = 0; i < profundidade; i++) {
            resp += "\t";
        }
       resp += "No("+ conteudo+ "){\n";
        for (No each : this.getFilhos()) {
            resp += each.toString(profundidade+1);
        }
        return resp;
    }
    
    
}
