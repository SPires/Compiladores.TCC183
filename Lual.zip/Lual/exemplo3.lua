for i=1,10,1
do
	print(i)
end
