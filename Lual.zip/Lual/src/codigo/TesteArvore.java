/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package codigo;

/**
 *
 * @author Rodrigo
 */
public class TesteArvore {
    public static void main(String[] args) {
        No raiz = new No(null, "raiz");
        No.novoFilho(raiz,"filho1");
        No.novoFilho(raiz, "filho2");
        No.novoFilho(raiz, "filho3");
        No.novoFilho(raiz.getFilhos().get(0), "neto1");
        System.out.println(raiz);
    }
}
